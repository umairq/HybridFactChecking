1. ***true_facts_train.txt*** file contains all true facts from the ***dataset/train.txt***.
2. Each model is trained on (1) with default configurations.
3. Each file for knowledge graph embedding models contains embeddings and details about configurations.
4. To generate embeddings, we used https://github.com/dice-group/DAIKIRI-Embedding.